attribute @s max_health modifier add upgradedmobs:evokers/boost 4 add_multiplied_base

# effect give @s instant_health 1 200 true

# item replace entity @s weapon.offhand with totem_of_undying

execute if score $global upgradedmobs.evokers.raid matches 1.. if data entity @s RaidId run data modify entity @s DeathLootTable set value "upgradedmobs:entities/raid/evoker"

tag @s add upgradedmobs.boosted
