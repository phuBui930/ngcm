# attribute @s movement_speed modifier add upgradedmobs:all/speed_increase 0.2 add_multiplied_base

# tag @s add upgradedmobs.all.speed
