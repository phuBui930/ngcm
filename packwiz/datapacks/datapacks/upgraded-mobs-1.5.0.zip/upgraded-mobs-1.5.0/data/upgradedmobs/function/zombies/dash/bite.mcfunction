# execute at @s run damage @p[distance=..1.5,gamemode=!creative,gamemode=!spectator] 6 mob_attack by @s from @s
