data modify entity @s Item.components merge from storage upgradedmobs:witch/potion/storage components
data modify entity @s Motion set from storage upgradedmobs:witch/potion/storage Motion
data modify entity @s Owner set from storage upgradedmobs:witch/potion/storage Owner
data modify entity @s Rotation set from storage upgradedmobs:witch/potion/storage Rotation

data merge entity @s {Tags:["upgradedmobs.witches.potion", "upgradedmobs.witches.potion.checked"], HasBeenShot:true, LeftOwner:true}

