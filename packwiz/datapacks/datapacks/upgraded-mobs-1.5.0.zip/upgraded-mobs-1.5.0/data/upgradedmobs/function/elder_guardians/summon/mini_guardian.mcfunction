summon guardian ~ ~ ~ {Health:2,attributes:[{id:"max_health",base:2}], Tags:[upgradedmobs.guardians.summoned], DeathLootTable:"entities/endermite"}

particle minecraft:squid_ink ~ ~ ~ 1 1 1 0.1 500 normal
playsound minecraft:block.respawn_anchor.set_spawn block @a ~ ~ ~ 1.5 0.9
