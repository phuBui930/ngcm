execute store result score @s upgradedmobs.health run data get entity @s Health 1

execute unless entity @s[nbt={active_effects:[{id:"minecraft:regeneration"}]}] if score @s upgradedmobs.health matches ..60 run effect give @s regeneration 5 1
